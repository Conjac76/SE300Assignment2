package com.se300.ledger.parametrized;
import com.se300.ledger.*;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

public class ParametrizedTest {
    @ParameterizedTest
    @ValueSource(strings = {"connor", "jacobs"})
    void testDuplicateAccount(String name) throws LedgerException {
        Ledger ledger = Ledger.getInstance("Test", "test Ledger", "chapman");
        ledger.createAccount(name);
        assertThrows(LedgerException.class, () -> ledger.createAccount(name));
    }

    @ParameterizedTest
    @CsvSource({"Alice", "Bob", "Eve"})
    void testAccountCreation(String accountName) throws LedgerException {
        Ledger ledger = Ledger.getInstance("Test", "test Ledger", "chapman");
        Account account = ledger.createAccount(accountName);
        assertNotNull(account);
    }

}
