package com.se300.ledger.stubs;

import com.se300.ledger.*;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mockito;

import static org.mockito.Mockito.*;

public class StubTest { 
    @Test
    void testNegativeAmountValue() throws LedgerException {
        Ledger ledger = Ledger.getInstance("Test", "test Ledger", "chapman");

        Transaction sampleTransaction = mock(Transaction.class);
        when(sampleTransaction.getAmount()).thenReturn(-1);

        assertThrows(LedgerException.class, () -> ledger.processTransaction(sampleTransaction));
    }

    @Test
    void testPayerBalanceCheck() throws LedgerException {
        Ledger ledger = Ledger.getInstance("Test", "test Ledger", "chapman");
        Account connor = Mockito.mock(Account.class);
        Account jacob = Mockito.mock(Account.class);

        Transaction sampleTransaction = new Transaction("1", 100, 10, "transaction", jacob, connor);
        assertThrows(LedgerException.class, () -> ledger.processTransaction(sampleTransaction));
        Mockito.verify(jacob, Mockito.times(1)).getBalance();
    }
}
