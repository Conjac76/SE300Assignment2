package com.se300.ledger.assumptions;
import static org.junit.jupiter.api.Assumptions.assumeFalse;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import org.junit.jupiter.api.Test;

import com.se300.ledger.Account;


public class AssumptionsTest {
    @Test
    public void testAssumePositiveBalance() {
        Account account = new Account("Alice", 100);

        assumeTrue(account.getBalance() >= 0, "The account balance should be positive for this test");
        // If the account has a positive balance, this test continues; otherwise, it is aborted
        // Your test logic for an account with a positive balance
    }

    @Test
    public void testAssumeNonNegativeBalance() {
        Account account = new Account("Bob", 0);

        assumeTrue(account.getBalance() >= 0, "The account balance should be non-negative for this test");
        // If the account has a non-negative balance, this test continues; otherwise, it is aborted
        // Your test logic for an account with a non-negative balance
    }

    @Test
    public void testAssumeAddressNotEmpty() {
        Account account = new Account("", 75);

        assumeFalse(account.getAddress().isEmpty(), "The account address should not be empty for this test");
        // If the account address is not empty, this test continues; otherwise, it is aborted
        // Your test logic for an account with a non-empty address
    }
}
