package com.se300.ledger.command;
import com.se300.ledger.*;


import org.junit.jupiter.api.Test;
import java.net.URISyntaxException;

/**
 * Test Driver Class for testing Blockchain
 *
 * @author  Sergey L. Sundukovskiy
 * @version 1.0
 * @since   2023-10-11
 */
public class DriverTest {

    public void testDriver() throws URISyntaxException, LedgerException {
        
    }
}
