package com.se300.ledger.mocks;


import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;
import com.se300.ledger.*;


public class MockTest {
    @Test
    void testPayerBalanceCheck() throws LedgerException {
        Ledger ledger = Ledger.getInstance("Test", "test Ledger", "chapman");
        Account connor = mock(Account.class);
        Account jacob = mock(Account.class);

        Transaction sampleTransaction = new Transaction("1", 100, 10, "transaciton",jacob, connor);
        assertThrows(LedgerException.class, () -> ledger.processTransaction(sampleTransaction));
        verify(jacob, times(1)).getBalance();
    }

    @Test
    void testTransactionFeeRequirement() {
        Ledger ledger = Ledger.getInstance("Test", "test Ledger", "chapman");
        Account buyer = mock(Account.class);
        Account seller = mock(Account.class);

        Transaction transaction = new Transaction("1", 100, 5, "Purchase", buyer, seller);

        assertThrows(LedgerException.class, () -> ledger.processTransaction(transaction));
    }

}



