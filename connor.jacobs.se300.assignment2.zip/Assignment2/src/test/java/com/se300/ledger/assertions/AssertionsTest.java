package com.se300.ledger.assertions;
import com.se300.ledger.*;


import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;

public class AssertionsTest {

    private Ledger ledger;

    @BeforeEach
    void setUp() {
        // Initialize a new ledger before each test
        ledger = Ledger.getInstance("TestLedger", "Test Ledger Description", "TestSeed");
    }

    @Test
    public void testBalanceUpdate() {
        // Demonstrate regular assertion for balance update
        Account account = new Account("Alice", 100);
        account.setBalance(150);
        assertEquals(150, account.getBalance());
    }

    @Test
    public void testExceptionHandling() throws LedgerException {
        // Demonstrate exception testing
        Ledger ledger = Ledger.getInstance("MyLedger", "Description", "Seed");

        // Create an account and then set the balance
        Account account = ledger.createAccount("NegativeBalanceAccount");
        account.setBalance(-50);

        // Attempt to process a transaction with a negative balance
        assertThrows(LedgerException.class, () -> {
            ledger.processTransaction(new Transaction("Transaction1", -50, 10, "Test", account, new Account("Receiver", 0)));
        });
    }

    @Test
    public void testTransactionFeeTooLowException() throws LedgerException {
        // Test processing a transaction with a fee that is too low
        Ledger ledger = Ledger.getInstance("MyLedger", "Description", "Seed");

        Account payer = ledger.createAccount("Payer");
        Account receiver = ledger.createAccount("Receiver");
        
        assertThrows(LedgerException.class, () -> {
            ledger.processTransaction(new Transaction("Transaction1", 1000, 5, "Test", payer, receiver));
        });
    }
}
