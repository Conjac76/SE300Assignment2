package com.se300.ledger.complete;

import com.se300.ledger.*;
import com.se300.ledger.command.CommandProcessorException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class CompleteTest {



    @Test
    public void testTransactionInitialization() {
        Account payer = new Account("122", 1000);
        Account receiver = new Account("Receiver", 100000);
        Transaction transaction = new Transaction("TX123", 100, 10, "Test Transaction", payer, receiver);

        assertEquals("TX123", transaction.getTransactionId());
        assertEquals(Integer.valueOf(100), transaction.getAmount());
        assertEquals(Integer.valueOf(10), transaction.getFee());
        assertEquals("Test Transaction", transaction.getNote());
        assertEquals(payer, transaction.getPayer());
        assertEquals(receiver, transaction.getReceiver());
    }

    @Test
    public void testSetTransactionId() {
        Transaction transaction = new Transaction("TX123", 100, 10, "Test Transaction", new Account("10", 10000), new Account("1", 1000));
        transaction.setTransactionId("TX456");
        assertEquals("TX456", transaction.getTransactionId());
    }

    @Test
    public void testSetReceiver() {
        Transaction transaction = new Transaction("TX123", 100, 10, "Test Transaction", new Account("10", 10000), new Account("10", 10000));
        Account receiver = new Account("New Receiver", 10000);
        transaction.setReceiver(receiver);
        assertEquals(receiver, transaction.getReceiver());
    }

    @Test
    public void testSetPayer() {
        Transaction transaction = new Transaction("TX123", 100, 10, "Test Transaction", new Account("10", 10000), new Account("10", 10000));
        Account payer = new Account("New Payer", 10000);
        transaction.setPayer(payer);
        assertEquals(payer, transaction.getPayer());
    }

    @Test
    public void testSetNote() {
        Transaction transaction = new Transaction("TX123", 100, 10, "Test Transaction", new Account("10", 10000), new Account("10", 10000));
        transaction.setNote("New Note");
        assertEquals("New Note", transaction.getNote());
    }

    @Test
    public void testSetFee() {
        Transaction transaction = new Transaction("TX123", 100, 10, "Test Transaction", new Account("10", 10000), new Account("10", 10000));
        transaction.setFee(20);
        assertEquals(Integer.valueOf(20), transaction.getFee());
    }

    @Test
    public void testSetAmount() {
        Transaction transaction = new Transaction("TX123", 100, 10, "Test Transaction", new Account("10", 10000), new Account("10", 10000));
        transaction.setAmount(200);
        assertEquals(Integer.valueOf(200), transaction.getAmount());
    }

    // @Test
    // public void testLedgerExceptionGetAction() {
    //     LedgerException exception = new LedgerException("ActionTest", "ReasonTest");
    //     assertEquals("ActionTest", exception.getAction());
    // }

    // @Test
    // public void testLedgerExceptionGetReason() {
    //     LedgerException exception = new LedgerException("ActionTest", "ReasonTest");
    //     assertEquals("ReasonTest", exception.getReason());
    // }

    // @Test
    // public void testLedgerExceptionConstructor() {
    //     LedgerException exception = new LedgerException("ActionTest", "ReasonTest");
    //     assertEquals("ActionTest", exception.getAction());
    //     assertEquals("ReasonTest", exception.getReason());
    // }

    // @Test
    // public void testLedgerExceptionSetAction() {
    //     LedgerException exception = new LedgerException("ActionTest", "ReasonTest");
    //     exception.setAction("UpdatedAction");
    //     assertEquals("UpdatedAction", exception.getAction());
    // }

    // @Test
    // public void testLedgerExceptionSetReason() {
    //     LedgerException exception = new LedgerException("ActionTest", "ReasonTest");
    //     exception.setReason("UpdatedReason");
    //     assertEquals("UpdatedReason", exception.getReason());
    // }

    // @Test
    // public void testSetSeed() {
    //     Ledger ledger = Ledger.getInstance("Test", "test Ledger", "chapman");
    //     ledger.setSeed("newSeed");
    //     assertEquals("newSeed", ledger.getSeed());
    // }

    // @Test
    // public void testSetName() {
    //     Ledger ledger = Ledger.getInstance("Test", "test Ledger", "chapman");
    //     ledger.setName("NewName");
    //     assertEquals("NewName", ledger.getName());
    // }

    // @Test
    // public void testSetDescription() {
    //     Ledger ledger = Ledger.getInstance("Test", "test Ledger", "chapman");
    //     ledger.setDescription("NewDescription");
    //     assertEquals("NewDescription", ledger.getDescription());
    // }

    // @Test
    // public void testGetUncommittedBlock() {
    //     Ledger ledger = Ledger.getInstance("Test", "test Ledger", "chapman");
    //     Block uncommittedBlock = ledger.getUncommittedBlock();
    //     assertNotNull(uncommittedBlock);
    // }

    // @Test
    // public void testGetSeed() {
    //     // The seed should be "chapman" initially
    //     Ledger ledger = Ledger.getInstance("Test", "test Ledger", "chapman");
    //     assertEquals("chapman", ledger.getSeed());
    // }

    // @Test
    // public void testGetName() {
    //     // The name should be "Test" initially
    //     Ledger ledger = Ledger.getInstance("Test", "test Ledger", "chapman");
    //     assertEquals("Test", ledger.getName());
    // }
   
    // @Test
    // public void testGetInstance() {
    //     Ledger ledger = Ledger.getInstance("Test", "test Ledger", "chapman");
    //     assertNotNull(ledger);
    // }

    // @Test
    // public void testGetDescription() {
    //     Ledger ledger = Ledger.getInstance("Test", "test Ledger", "chapman");
    //     assertEquals("NewDescription", ledger.getDescription());
    // }
   
    // @Test
    // public void testCreateAccount() throws LedgerException {
    //     Ledger ledger = Ledger.getInstance("Test", "test Ledger", "chapman");
    //     assertNotNull(ledger.createAccount("newAccount"));
    // }

    @Test
    public void testAccountConstructor() {
        Account account = new Account("testAccount", 100);
        assertEquals("testAccount", account.getAddress());
        assertEquals(100, account.getBalance());
    }

    @Test
    public void testSetAddress() {
        Account account = new Account("originalAddress", 100);
        account.setAddress("newAddress");
        assertEquals("newAddress", account.getAddress());
    }

    @Test
    public void testSetBalance() {
        Account account = new Account("testAccount", 100);
        account.setBalance(200);
        assertEquals(200, account.getBalance());
    }

    @Test
    public void testClone() {
        Account originalAccount = new Account("testAccount", 100);
        Account clonedAccount = (Account) originalAccount.clone();
        assertNotSame(originalAccount, clonedAccount);
        assertEquals(originalAccount.getAddress(), clonedAccount.getAddress());
        assertEquals(originalAccount.getBalance(), clonedAccount.getBalance());
    }

    @Test
    public void testBlockConstructor() {
        Block block = new Block(1, "0");
        assertEquals(1, block.getBlockNumber());
        assertEquals("0", block.getPreviousHash());
        assertNull(block.getHash());
        assertNull(block.getPreviousBlock());
        assertTrue(block.getTransactionList().isEmpty());
        assertTrue(block.getAccountBalanceMap().isEmpty());
    }

    @Test
    public void testSetBlockNumber() {
        Block block = new Block(1, "0");
        block.setBlockNumber(2);
        assertEquals(2, block.getBlockNumber());
    }

    @Test
    public void testSetPreviousHash() {
        Block block = new Block(1, "0");
        block.setPreviousHash("1");
        assertEquals("1", block.getPreviousHash());
    }

    @Test
    public void testSetHash() {
        Block block = new Block(1, "0");
        block.setHash("blockHash");
        assertEquals("blockHash", block.getHash());
    }

    @Test
    public void testAddAccount() {
        Block block = new Block(1, "0");
        Account account = new Account("testAccount", 100);
        block.addAccount("testAccount", account);
        assertEquals(account, block.getAccount("testAccount"));
    }

    @Test
    public void testGetAccount() {
        Block block = new Block(1, "0");
        Account account = new Account("testAccount", 100);
        block.addAccount("testAccount", account);
        Account retrievedAccount = block.getAccount("testAccount");
        assertEquals(account, retrievedAccount);
    }

    @Test
    public void testSetPreviousBlock() {
        Block block = new Block(1, "0");
        Block previousBlock = new Block(0, "genesis");
        block.setPreviousBlock(previousBlock);
        assertEquals(previousBlock, block.getPreviousBlock());
    }

    // @Test
    // void testProcessTransactionInvalidAmount() throws LedgerException {
    //     Ledger ledger = Ledger.getInstance("Test Ledger", "Test Description", "Test Seed");
    //     Account payer = ledger.createAccount("payer");
    //     Account receiver = ledger.createAccount("receiver");

    //     // Set an initial balance for the payer and receiver accounts
    //     payer.setBalance(500);  // Initial balance for payer
    //     receiver.setBalance(100);  // Initial balance for receiver
    //     // Create a transaction with an invalid amount
    //     Transaction transaction = new Transaction("12345", -1, 20, "Invalid Transaction", payer, receiver);

    //     // Verify that processing this transaction throws a LedgerException
    //     assertThrows(LedgerException.class, () -> ledger.processTransaction(transaction));
    // }

    void testGetAccountBalance() throws LedgerException {

        Ledger ledger = Ledger.getInstance("Test Ledger", "Test Description", "Test Seed");
        
        // Create payer and receiver accounts
        Account payer = ledger.createAccount("payer");
        Account receiver = ledger.createAccount("receiver");
        
        // Set initial balances for payer and receiver accounts
        payer.setBalance(500);
        receiver.setBalance(100);


        try {
            int expectedPayerBalance = 500;
            int expectedReceiverBalance = 100;

            int actualPayerBalance = ledger.getAccountBalance("payer");
            int actualReceiverBalance = ledger.getAccountBalance("receiver");

            assertEquals(expectedPayerBalance, actualPayerBalance, "Payer's account balance should match the expected value.");
            assertEquals(expectedReceiverBalance, actualReceiverBalance, "Receiver's account balance should match the expected value.");
        } catch (LedgerException e) {
            fail("Exception thrown: " + e.getMessage());
        }
    }
    @Test
    public void testProcessTransactionNoteLengthExceedsLimit() throws LedgerException {
        Ledger ledger = Ledger.getInstance("Test Ledger", "Test Description", "Test Seed");
        
        // Create payer and receiver accounts
        Account payer = ledger.createAccount("payer");
        Account receiver = ledger.createAccount("receiver");
        
        // Set initial balances for payer and receiver accounts
        payer.setBalance(500);
        receiver.setBalance(100);

        try {
            String longNote = "nzjfxoodeopvyhdoefwxealxbgldwhdcjklfpqlnaogwtpgsivtuflgkxxobaxecmriyjffhegoowunmpqhadeexqkkeeyzlmejjngmvnzzugccpyjqszwnrgdcmrljeksueldjqbdmlfuhbcpvcmbltpijfsnbogskfnrcahdwqqxseznxoqnhnfcokhpiwzoprqxwvlxsfrgmdvjgdwdieeukeaehbbgjvmfeheylmwgiylmdqzwoqxwxhybkdaukicabjaarpivvuaspugaprnecpoqejnahpptbpkkoggtkokmsznmydtqpfhqeudelzoizeaemuhdejdmzypnrlnytorergqucrgzognuottmdunluggzcykszkwhscrkmxcipvznewyqvaeahfryprreixiygdyfadhrmvjefqkpceavateyciacvnxrltpdrylvjwyadejdksmnjvzvnrwkyqlvriubkxqawpsnyshmxjdlshovsrnyjbeocljfchlbcerpxkgqzjbwqzdndrwznmfidvifbdmfkkfflgvfpfkxovxylaqagnqhflqusyylwctqgsttfvfzryuaofvbvjlcctuaiiwtxjdjgpxwkvsaqoyzhswagitrhjiehjxckyhujdturtnaxmepyftfnrryypabwfczpbhqwezuympdncezmabgcvylliipoppbnpttigyrilwousyracwecignouwqsybiezqyjghqdnwvneghdteqhsapzqelalwlxholornlnznvkcxlgxifegrvshfgxwhnnrhuvbpaucntsmrytkvsxeycsgxipilxumtkqndanmrrhpugbuijbbwrixxlcgdvhjhtoekcsitnijrlqccmlhuxyvogfoohrsllwewjiouxzjdcpsymcujwshzdgoxoxhsmuppnofqbwryxdtolpeomhtsgbmbfmjtjwkajgthqsjzivftaionvreozntvpoxxmvzstpdzqlxwhsurmwgpkpbl"; // Create a note longer than 1024 characters
            Transaction transaction = new Transaction("12345", 100, 10, longNote, payer, receiver);
            
            ledger.processTransaction(transaction); // This should throw LedgerException
            fail("Expected LedgerException was not thrown");
        } catch (LedgerException e) {
            assertEquals("Process Transaction", e.getAction());
            assertEquals("Note Length Must Be Less Than 1024 Chars", e.getReason());
        }
    }
}


